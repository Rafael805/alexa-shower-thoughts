/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/
/**
 * This sample demonstrates a simple skill built with the Amazon Alexa Skills
 * nodejs skill development kit.
 * This sample supports multiple lauguages. (en-US, en-GB, de-DE).
 * The Intent Schema, Custom Slots and Sample Utterances for this skill, as well
 * as testing instructions are located at https://github.com/alexa/skill-sample-nodejs-fact
 **/

'use strict';
var Alexa = require('alexa-sdk');
var request = require('request');

const APP_ID = "amzn1.ask.skill.9591e073-59f3-405c-af95-064388bc7291";


const GET_THOUGHT = "Here's your shower thought of the day: ";
const HELP_MESSAGE = "You can ask for a shower thought, or, you can say exit... What can I help you with?";
const HELP_REPROMPT = "What can I help you with?";
const STOP_MESSAGE = "Goodbye!";

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.APP_ID = APP_ID;
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function () {
        this.emit('ShowerThoughtIntent');
    },
    'ShowerThoughtIntent': function () {
        var scope = this;
        // https://www.reddit.com/r/Showerthoughts/new.json?sort=new
        request('https://www.reddit.com/r/Showerthoughts/.json', function(error, response, body){
            var resp = JSON.parse(body);
            var random = Math.floor(Math.random() * resp.data.children.length);
            var Text = resp.data.children[random].data.title;
            var speechOutput = GET_THOUGHT + " <break time='1s'/> " + Text;
            scope.emit(':tell', speechOutput)
        })
    },
    'AMAZON.HelpIntent': function () {
        var speechOutput = HELP_MESSAGE;
        var reprompt = HELP_REPROMPT;
        this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.CancelIntent': function () {
        this.emit(':tell', STOP_MESSAGE);
    },
    'AMAZON.StopIntent': function () {
        this.emit(':tell', STOP_MESSAGE);
    }
};
